package com.vulpis.storyraft

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.provider.Settings
import android.os.Handler
import android.os.Looper
import androidx.core.content.FileProvider
import com.google.firebase.firestore.FirebaseFirestore
import java.io.File

object StoryRaftUpdater {
    data class Release(val version: String, val notes: String, val apkUrl: String)

    // Firestore document: app_config/current
    // Fields: version (String), notes (String), apkUrl (String)
    fun check(callback: (Result<Release>) -> Unit) {
        FirebaseFirestore.getInstance()
            .collection("app_config")
            .document("current")
            .get()
            .addOnSuccessListener { doc ->
                try {
                    require(doc.exists()) { "Firebase app_config/current document was not found." }
                    val version = doc.getString("version").orEmpty()
                    val notes = doc.getString("notes") ?: "No release notes."
                    val apkUrl = doc.getString("apkUrl").orEmpty()
                    require(version.isNotBlank()) { "Firebase update document is missing version." }
                    require(apkUrl.startsWith("https://")) { "Firebase update document needs a valid HTTPS apkUrl." }
                    callback(Result.success(Release(version, notes, apkUrl)))
                } catch (e: Exception) {
                    callback(Result.failure(e))
                }
            }
            .addOnFailureListener { callback(Result.failure(it)) }
    }

    fun isNewer(latest: String, installed: String): Boolean {
        fun parts(v: String) = v.split('.', '-', '+').map { it.toIntOrNull() ?: 0 }
        val a = parts(latest); val b = parts(installed)
        for (i in 0 until maxOf(a.size, b.size)) {
            val x = a.getOrElse(i) { 0 }; val y = b.getOrElse(i) { 0 }
            if (x != y) return x > y
        }
        return false
    }

    fun download(context: Context, release: Release) {
        val request = DownloadManager.Request(Uri.parse(release.apkUrl))
            .setTitle("StoryRaft ${release.version}")
            .setDescription("Downloading StoryRaft update")
            .setMimeType("application/vnd.android.package-archive")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalFilesDir(context, Environment.DIRECTORY_DOWNLOADS, "storyraft-update.apk")
        context.getSharedPreferences("storyraft_updates", Context.MODE_PRIVATE).edit()
            .putString("pending_version", release.version).apply()
        val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        manager.enqueue(request)
    }

    fun installPending(context: Context) {
        val prefs = context.getSharedPreferences("storyraft_updates", Context.MODE_PRIVATE)
        val target = prefs.getString("pending_version", null) ?: return
        val apk = File(context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "storyraft-update.apk")
        if (!apk.isFile) return
        if (!isNewer(target, BuildConfig.VERSION_NAME)) {
            apk.delete()
            prefs.edit().remove("pending_version").apply()
            return
        }
        if (android.os.Build.VERSION.SDK_INT >= 26 && !context.packageManager.canRequestPackageInstalls()) {
            val settings = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${context.packageName}"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(settings)
            return
        }
        val uri = FileProvider.getUriForFile(context, "com.vulpis.storyraft.fileprovider", apk)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(intent)
    }
}
