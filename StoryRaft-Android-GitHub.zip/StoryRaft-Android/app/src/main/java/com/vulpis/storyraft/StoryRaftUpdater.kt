package com.vulpis.storyraft

import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.provider.Settings
import android.os.Handler
import android.os.Looper
import androidx.core.content.FileProvider
import java.io.File

object StoryRaftUpdater {
    data class Release(val version: String, val notes: String, val apkUrl: String)

    fun check(callback: (Result<Release>) -> Unit) {
        Thread {
            try {
                val repo = BuildConfig.UPDATE_REPOSITORY
                require(!repo.contains("OWNER") && repo.contains("/")) {
                    "Set UPDATE_REPOSITORY in app/build.gradle.kts to your GitHub owner/repository."
                }
                val connection = java.net.URL("https://api.github.com/repos/$repo/releases/latest")
                    .openConnection() as java.net.HttpURLConnection
                connection.connectTimeout = 15000
                connection.readTimeout = 15000
                connection.setRequestProperty("Accept", "application/vnd.github+json")
                connection.setRequestProperty("User-Agent", "StoryRaft-Android")
                try {
                    val json = org.json.JSONObject(connection.inputStream.bufferedReader().use { it.readText() })
                    val assets = json.getJSONArray("assets")
                    var apkUrl: String? = null
                    for (i in 0 until assets.length()) {
                        val asset = assets.getJSONObject(i)
                        if (asset.optString("name").endsWith(".apk", ignoreCase = true)) {
                            apkUrl = asset.optString("browser_download_url")
                            break
                        }
                    }
                    require(!apkUrl.isNullOrBlank()) { "The latest GitHub release does not contain an APK asset." }
                    val version = json.optString("tag_name", "").removePrefix("v").ifBlank { "0.0.0" }
                    val found = Release(version, json.optString("body", "No release notes."), apkUrl!!)
                    Handler(Looper.getMainLooper()).post { callback(Result.success(found)) }
                } finally { connection.disconnect() }
            } catch (e: Exception) { Handler(Looper.getMainLooper()).post { callback(Result.failure(e)) } }
        }.start()
    }

    fun isNewer(latest: String, installed: String): Boolean {
        fun parts(v: String) = v.split('.', '-', '+').map { it.toIntOrNull() ?: 0 }
        val a = parts(latest); val b = parts(installed)
        for (i in 0 until maxOf(a.size, b.size)) {
            val x = a.getOrElse(i) { 0 }; val y = b.getOrElse(i) { 0 }
            if (x != y) return x > y
        }
        return false
    }

    fun download(context: Context, release: Release) {
        val request = DownloadManager.Request(Uri.parse(release.apkUrl))
            .setTitle("StoryRaft ${release.version}")
            .setDescription("Downloading StoryRaft update")
            .setMimeType("application/vnd.android.package-archive")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalFilesDir(context, Environment.DIRECTORY_DOWNLOADS, "storyraft-update.apk")
        context.getSharedPreferences("storyraft_updates", Context.MODE_PRIVATE).edit()
            .putString("pending_version", release.version).apply()
        val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        manager.enqueue(request)
    }

    // Called when StoryRaft returns to the foreground. Android still shows its normal install confirmation.
    fun installPending(context: Context) {
        val prefs = context.getSharedPreferences("storyraft_updates", Context.MODE_PRIVATE)
        val target = prefs.getString("pending_version", null) ?: return
        val apk = File(context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "storyraft-update.apk")
        if (!apk.isFile) return // Download is not finished yet.
        if (!isNewer(target, BuildConfig.VERSION_NAME)) {
            apk.delete()
            prefs.edit().remove("pending_version").apply()
            return
        }
        if (android.os.Build.VERSION.SDK_INT >= 26 && !context.packageManager.canRequestPackageInstalls()) {
            val settings = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${context.packageName}"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(settings)
            return
        }
        val uri = FileProvider.getUriForFile(context, "com.vulpis.storyraft.fileprovider", apk)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(intent)
    }
}
