package com.vulpis.storyraft

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.compose.ui.platform.LocalContext
import coil.compose.AsyncImage
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration

private val Navy = Color(0xFF081B3D)
private val Blue = Color(0xFF1768C5)
private val Paper = Color(0xFFF4EFE6)
private val Ink = Color(0xFF202733)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FirebaseApp.initializeApp(this)
        setContent { StoryRaftApp() }
    }
}

data class ChapterMeta(val id: String, val title: String, val part: String?, val at: Long?)
data class Story(
    val id: String, val title: String, val author: String, val intro: String,
    val thumb: String?, val updatedAt: Long, val createdAt: Long,
    val chapters: List<ChapterMeta>, val notWriter: Boolean
)
data class Scene(val id: String, val name: String, val text: String, val size: Int, val bold: Boolean, val italic: Boolean, val align: String)

class StoryRepository {
    private val db = FirebaseFirestore.getInstance()
    fun observeStories(onResult: (List<Story>, String?) -> Unit): ListenerRegistration {
        return db.collection("stories").addSnapshotListener { snap, err ->
            if (err != null) { onResult(emptyList(), err.localizedMessage); return@addSnapshotListener }
            val rows = snap?.documents.orEmpty().mapNotNull { d ->
                val rawChapters = d.get("chapters") as? List<Map<String, Any?>> ?: emptyList()
                val chapters = rawChapters.mapNotNull { c ->
                    val id = c["id"] as? String ?: return@mapNotNull null
                    ChapterMeta(id, c["title"] as? String ?: "", c["part"] as? String, (c["at"] as? Number)?.toLong())
                }
                Story(d.id, d.getString("title") ?: "Untitled", d.getString("author") ?: "Unknown",
                    d.getString("intro") ?: "", d.getString("thumb"),
                    (d.get("updatedAt") as? Number)?.toLong() ?: (d.get("createdAt") as? Number)?.toLong() ?: 0L,
                    (d.get("createdAt") as? Number)?.toLong() ?: 0L, chapters, d.getBoolean("notWriter") ?: false)
            }.sortedByDescending { it.updatedAt }
            onResult(rows, null)
        }
    }
    fun loadChapter(storyId: String, chapterId: String, onResult: (List<Scene>, String?) -> Unit) {
        db.collection("chapters").document("${storyId}_${chapterId}").get()
            .addOnSuccessListener { doc ->
                val scenes = (doc.get("scenes") as? List<Map<String, Any?>>).orEmpty().map { s ->
                    val fmt = s["fmt"] as? Map<*, *> ?: emptyMap<Any, Any>()
                    Scene(s["id"] as? String ?: "", s["name"] as? String ?: "", s["text"] as? String ?: "",
                        (fmt["size"] as? Number)?.toInt() ?: 18, fmt["bold"] as? Boolean ?: false,
                        fmt["italic"] as? Boolean ?: false, fmt["align"] as? String ?: "justify")
                }
                onResult(scenes, null)
            }.addOnFailureListener { onResult(emptyList(), it.localizedMessage) }
    }
}

@Composable fun StoryRaftApp() {
    val repo = remember { StoryRepository() }
    var stories by remember { mutableStateOf(emptyList<Story>()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var tab by remember { mutableStateOf("Home") }
    var tabHistory by remember { mutableStateOf(emptyList<String>()) }
    var selected by remember { mutableStateOf<Story?>(null) }
    var reading by remember { mutableStateOf(false) }
    var chapterIndex by remember { mutableIntStateOf(0) }
    var scenes by remember { mutableStateOf(emptyList<Scene>()) }
    var sceneError by remember { mutableStateOf<String?>(null) }
    var query by remember { mutableStateOf("") }
    var searchOpen by remember { mutableStateOf(false) }
    var continuous by remember { mutableStateOf(false) }
    var bookmarked by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val savedPrefs = remember { context.getSharedPreferences("storyraft_library", android.content.Context.MODE_PRIVATE) }
    var savedStoryIds by remember { mutableStateOf(savedPrefs.getStringSet("saved_ids", emptySet())?.toSet() ?: emptySet()) }
    fun toggleSaved(storyId: String) {
        val next = if (storyId in savedStoryIds) savedStoryIds - storyId else savedStoryIds + storyId
        savedStoryIds = next
        savedPrefs.edit().putStringSet("saved_ids", next).apply()
    }
    // Handle Android system Back according to the current navigation depth.
    BackHandler(enabled = reading || selected != null || tab != "Home") {
        when {
            reading -> reading = false
            selected != null -> selected = null
            tabHistory.isNotEmpty() -> {
                tab = tabHistory.last()
                tabHistory = tabHistory.dropLast(1)
            }
            else -> tab = "Home"
        }
    }
    DisposableEffect(repo) { val listener = repo.observeStories { rows, e -> stories = rows; error = e; loading = false }; onDispose { listener.remove() } }
    MaterialTheme(colorScheme = lightColorScheme(primary = Blue, background = Paper, surface = Paper, onBackground = Ink, onSurface = Ink)) {
        if (reading && selected != null) {
            ReaderScreen(selected!!, chapterIndex, scenes, sceneError, continuous, { continuous = it }, bookmarked, { bookmarked = it },
                onBack = { reading = false }, onPrev = { if (chapterIndex > 0) { chapterIndex--; load(repo, selected!!, chapterIndex) { s,e -> scenes=s; sceneError=e } } },
                onNext = { if (chapterIndex < selected!!.chapters.lastIndex) { chapterIndex++; load(repo, selected!!, chapterIndex) { s,e -> scenes=s; sceneError=e } } })
        } else if (selected != null) {
            DetailScreen(selected!!, isSaved = selected!!.id in savedStoryIds, onToggleSaved = { toggleSaved(selected!!.id) }, onBack = { selected = null }, onRead = { idx -> chapterIndex = idx; load(repo, selected!!, idx) { s,e -> scenes=s; sceneError=e }; reading = true })
        } else {
            Scaffold(containerColor = Paper, bottomBar = {
                NavigationBar(containerColor = Navy, contentColor = Color.White) {
                    listOf("Home", "Library", "Dashboard", "History", "More").forEach { name ->
                        val icon = when(name) { "Home" -> Icons.Default.Home; "Library" -> Icons.Default.MenuBook; "Dashboard" -> Icons.Default.Dashboard; "History" -> Icons.Default.History; else -> Icons.Default.MoreVert }
                        NavigationBarItem(selected = tab == name, onClick = { if (tab != name) { tabHistory = tabHistory + tab; tab = name } }, icon = { Icon(icon, null) }, label = { Text(name, fontSize = 10.sp) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Color.White, selectedTextColor = Color.White, indicatorColor = Blue, unselectedIconColor = Color.LightGray, unselectedTextColor = Color.LightGray))
                    }
                }
            }) { pad ->
                Column(Modifier.fillMaxSize().padding(pad).background(Paper)) {
                    when(tab) {
                        "Home" -> HomeScreen(stories, loading, error, query, { query=it }, searchOpen, { searchOpen = !searchOpen; query = "" }, onOpen = { selected=it })
                        "Library" -> LibraryScreen(stories.filter { it.id in savedStoryIds }, query, { query=it }, searchOpen, { searchOpen = !searchOpen; query = "" }, onOpen = { selected=it })
                        "Dashboard" -> SimpleScreen("Dashboard", "Your reading activity and saved progress will appear here.")
                        "History" -> SimpleScreen("History", "Recently opened books will appear here.")
                        else -> SettingsScreen()
                    }
                }
            }
        }
    }
}

private fun load(repo: StoryRepository, story: Story, idx: Int, done: (List<Scene>, String?) -> Unit) {
    story.chapters.getOrNull(idx)?.let { repo.loadChapter(story.id, it.id, done) } ?: done(emptyList(), "This story has no chapters yet.")
}

@Composable private fun Header(title: String, searchOpen: Boolean? = null, onSearchClick: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().background(Navy).padding(start=20.dp, end=12.dp, top=7.dp, bottom=7.dp), verticalAlignment=Alignment.CenterVertically) {
        Text(title, color=Color.White, fontSize=25.sp, fontWeight=FontWeight.Bold, modifier=Modifier.weight(1f))
        if (onSearchClick != null) IconButton(onClick = onSearchClick) {
            Icon(if (searchOpen == true) Icons.Default.Close else Icons.Default.Search, contentDescription = if (searchOpen == true) "Close search" else "Search", tint=Color.White)
        }
    }
}
@Composable private fun SearchField(value: String, onChange: (String)->Unit) {
    OutlinedTextField(value, onChange, Modifier.fillMaxWidth().padding(horizontal=16.dp, vertical=10.dp), placeholder={Text("Search stories…")}, leadingIcon={Icon(Icons.Default.Search, null)}, singleLine=true, shape=RoundedCornerShape(16.dp))
}
@Composable private fun HomeScreen(stories: List<Story>, loading: Boolean, error: String?, query: String, onQuery: (String)->Unit, searchOpen: Boolean, onToggleSearch: ()->Unit, onOpen: (Story)->Unit) {
    Column(Modifier.fillMaxSize()) {
        Header("Home", searchOpen, onToggleSearch)
        if (searchOpen) SearchField(query, onQuery)
        LazyColumn(contentPadding=PaddingValues(bottom=16.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
            item {
                Column(Modifier.padding(horizontal=16.dp)) {
                    Text("Featured", fontSize=20.sp, fontWeight=FontWeight.Bold, color=Navy)
                    Box(Modifier.fillMaxWidth().height(148.dp).padding(top=8.dp).clip(RoundedCornerShape(18.dp)).background(Navy), contentAlignment=Alignment.Center) {
                        Column(horizontalAlignment=Alignment.CenterHorizontally) { Text("A sea of stories awaits", color=Color.White, fontSize=19.sp, fontWeight=FontWeight.SemiBold); Text("Featured banners will be connected to the admin feed", color=Color(0xFFB8D6FF), fontSize=11.sp) }
                    }
                }
            }
            item { SectionHeading("Recently Updated", "Latest changes first") }
            if (loading) item { CenterMessage("Loading stories from Firebase…") }
            if (error != null) item { CenterMessage("Firebase: $error") }
            val latest = stories.filter { it.title.contains(query, true) || it.author.contains(query, true) }.take(12)
            items(latest.chunked(3)) { row -> Row(Modifier.fillMaxWidth().padding(horizontal=16.dp), horizontalArrangement=Arrangement.spacedBy(10.dp)) { row.forEach { StoryCard(it, Modifier.weight(1f), onOpen) }; repeat(3 - row.size) { Spacer(Modifier.weight(1f)) } } }
            item { SectionHeading("Popular", "Discover reader favourites") }
            items(stories.filter { it.title.contains(query, true) || it.author.contains(query, true) }.take(10).chunked(3)) { row -> Row(Modifier.fillMaxWidth().padding(horizontal=16.dp), horizontalArrangement=Arrangement.spacedBy(10.dp)) { row.forEach { StoryCard(it, Modifier.weight(1f), onOpen) }; repeat(3 - row.size) { Spacer(Modifier.weight(1f)) } } }
        }
    }
}
@Composable private fun SectionHeading(title: String, caption: String) { Column(Modifier.padding(horizontal=16.dp, vertical=2.dp)) { Text(title, fontSize=20.sp, fontWeight=FontWeight.Bold, color=Navy); Text(caption, fontSize=12.sp, color=Color.Gray) } }
@Composable private fun StoryCard(story: Story, modifier: Modifier, onOpen: (Story)->Unit) {
    Column(modifier.clip(RoundedCornerShape(14.dp)).background(Color.White).clickable { onOpen(story) }.padding(9.dp)) {
        if (story.thumb != null) AsyncImage(story.thumb, null, Modifier.fillMaxWidth().height(128.dp).clip(RoundedCornerShape(10.dp)), contentScale=ContentScale.Crop)
        else Box(Modifier.fillMaxWidth().height(128.dp).clip(RoundedCornerShape(10.dp)).background(Navy), contentAlignment=Alignment.Center) { Text(story.title.take(32), color=Color.White, fontWeight=FontWeight.Bold, modifier=Modifier.padding(8.dp)) }
        Spacer(Modifier.height(7.dp)); Text(story.title, fontWeight=FontWeight.SemiBold, maxLines=2, overflow=TextOverflow.Ellipsis); Text(story.author, fontSize=12.sp, color=Color.Gray, maxLines=1)
    }
}
@Composable private fun LibraryScreen(stories: List<Story>, query: String, onQuery: (String)->Unit, searchOpen: Boolean, onToggleSearch: ()->Unit, onOpen: (Story)->Unit) {
    Column { Header("Library", searchOpen, onToggleSearch); if (searchOpen) SearchField(query,onQuery)
        val saved = stories.filter { it.title.contains(query,true) || it.author.contains(query,true) }
        if (saved.isEmpty()) Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment=Alignment.Center) { Text(if (query.isBlank()) "Your Library is empty. Save a book to see it here." else "No saved books match your search.", color=Color.Gray, textAlign=TextAlign.Center) }
        else LazyColumn(contentPadding=PaddingValues(14.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) {
            items(saved.chunked(3)) { row -> Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                row.forEach { s -> StoryCard(s, Modifier.weight(1f), onOpen) }
                repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
            } }
        }
    }
}
@Composable private fun DetailScreen(story: Story, isSaved: Boolean, onToggleSaved: ()->Unit, onBack: ()->Unit, onRead: (Int)->Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().background(Navy).padding(12.dp), verticalAlignment=Alignment.CenterVertically) { IconButton(onBack) { Icon(Icons.Default.ArrowBack,null,tint=Color.White) }; Text("Book Details",color=Color.White,fontSize=20.sp,fontWeight=FontWeight.Bold) }
        LazyColumn(Modifier.weight(1f), contentPadding=PaddingValues(18.dp)) {
            item { Row(horizontalArrangement=Arrangement.spacedBy(16.dp)) { if(story.thumb!=null) AsyncImage(story.thumb,null,Modifier.width(112.dp).height(160.dp).clip(RoundedCornerShape(12.dp)),contentScale=ContentScale.Crop) else Box(Modifier.width(112.dp).height(160.dp).background(Navy),contentAlignment=Alignment.Center){Text("StoryRaft",color=Color.White)}; Column(Modifier.weight(1f)) { Text(story.title,fontSize=22.sp,fontWeight=FontWeight.Bold,color=Navy); Text(story.author,color=Color.Gray); Spacer(Modifier.height(10.dp)); Text("${story.chapters.size} chapters",fontSize=13.sp); OutlinedButton(onClick=onToggleSaved) { Icon(if(isSaved) Icons.Default.Bookmark else Icons.Default.BookmarkBorder, null); Spacer(Modifier.width(5.dp)); Text(if(isSaved) "Remove from Library" else "Save to Library") }; OutlinedButton(onClick={if(story.chapters.isNotEmpty())onRead(0)},enabled=story.chapters.isNotEmpty()) { Text("Start reading") } } } }
            item { Spacer(Modifier.height(18.dp)); Text("About this book",fontWeight=FontWeight.Bold,fontSize=18.sp); Text(story.intro.ifBlank { "No synopsis has been added." },Modifier.padding(top=6.dp),lineHeight=22.sp) }
            item { Spacer(Modifier.height(20.dp)); Text("Chapters",fontWeight=FontWeight.Bold,fontSize=19.sp,color=Navy) }
            itemsIndexed(story.chapters) { idx, ch ->
                if (!ch.part.isNullOrBlank() && (idx==0 || story.chapters[idx-1].part != ch.part)) Text(ch.part,Modifier.fillMaxWidth().padding(top=14.dp,bottom=5.dp),fontSize=14.sp,color=Blue,fontWeight=FontWeight.SemiBold)
                Row(Modifier.fillMaxWidth().clickable { onRead(idx) }.padding(vertical=12.dp),verticalAlignment=Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(ch.title.ifBlank { "Chapter ${idx+1}" },fontWeight=FontWeight.Medium); Text("Chapter ${idx+1}",fontSize=11.sp,color=Color.Gray) }; Icon(Icons.Default.ChevronRight,null,tint=Blue) }
                HorizontalDivider(color=Color(0xFFE4DED4))
            }
        }
    }
}
@Composable private fun ReaderScreen(story: Story, index: Int, scenes: List<Scene>, error: String?, continuous: Boolean, onContinuous: (Boolean)->Unit, bookmarked: Boolean, onBookmark: (Boolean)->Unit, onBack: ()->Unit, onPrev: ()->Unit, onNext: ()->Unit) {
    val bg = Paper
    val fg = Ink
    var tools by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().background(bg)) {
        Row(Modifier.fillMaxWidth().background(Navy).padding(horizontal=8.dp, vertical=5.dp),verticalAlignment=Alignment.CenterVertically) { IconButton(onBack){Icon(Icons.Default.ArrowBack,null,tint=Color.White)}; Column(Modifier.weight(1f)){Text(story.title,color=Color.White,maxLines=1);Text("${index+1} / ${story.chapters.size}",color=Color.LightGray,fontSize=11.sp)}; IconButton(onClick={onBookmark(!bookmarked)}){Icon(if(bookmarked)Icons.Default.Bookmark else Icons.Default.BookmarkBorder,null,tint=Color.White)}; IconButton(onClick={tools=!tools}){Icon(Icons.Default.Tune,null,tint=Color.White)} }
        if(tools) Row(Modifier.fillMaxWidth().background(bg).padding(12.dp), verticalAlignment=Alignment.CenterVertically){Text("Continuous scroll",color=fg); Spacer(Modifier.width(8.dp)); Switch(continuous,onContinuous)}
        Text(story.chapters.getOrNull(index)?.title?.ifBlank { "Chapter ${index+1}" } ?: "",Modifier.align(Alignment.CenterHorizontally).padding(10.dp),color=fg,fontWeight=FontWeight.SemiBold)
        if(error!=null) CenterMessage(error) else if(scenes.isEmpty()) CenterMessage("Loading chapter…") else LazyColumn(Modifier.weight(1f).fillMaxWidth(),contentPadding=PaddingValues(horizontal=24.dp,vertical=18.dp)) {
            items(scenes) { scene -> Column(Modifier.fillMaxWidth().padding(bottom=18.dp)) { if(scene.name.isNotBlank()) Text(scene.name,color=fg,fontWeight=FontWeight.Bold); Text(scene.text,color=fg,fontSize=scene.size.sp,lineHeight=(scene.size*1.55).sp,fontWeight=if(scene.bold)FontWeight.Bold else FontWeight.Normal, fontStyle=if(scene.italic) FontStyle.Italic else FontStyle.Normal, textAlign=when(scene.align){"center"->TextAlign.Center;"end","right"->TextAlign.End;"start","left"->TextAlign.Start;else->TextAlign.Justify}) } }
        }
        Row(Modifier.fillMaxWidth().padding(12.dp),horizontalArrangement=Arrangement.SpaceBetween) { OutlinedButton(onClick=onPrev,enabled=index>0){Text("Previous")}; OutlinedButton(onClick=onNext,enabled=index<story.chapters.lastIndex){Text("Next chapter") } }
    }
}
@Composable private fun SettingsScreen() {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) { Header("More"); Text("Account",Modifier.padding(18.dp),fontWeight=FontWeight.Bold); Text(FirebaseAuth.getInstance().currentUser?.email ?: "Not signed in",Modifier.padding(horizontal=18.dp),color=Color.Gray); Text("Sign-in and account management are not yet connected to the interface.",Modifier.padding(18.dp),fontSize=12.sp,color=Color.Gray) }
}
@Composable private fun SimpleScreen(title:String,body:String){Column(Modifier.fillMaxSize()){Header(title);CenterMessage(body)}}
@Composable private fun CenterMessage(text:String){Box(Modifier.fillMaxWidth().padding(20.dp),contentAlignment=Alignment.Center){Text(text,color=Color.Gray)}}
