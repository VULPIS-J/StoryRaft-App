package com.vulpis.storyraft

import android.os.Bundle
import android.content.Context
import androidx.compose.ui.platform.LocalContext
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration

data class Series(val title:String, val chapter:String, val genre:String, val progress:Float, val colors:List<Color>)
class MainActivity:ComponentActivity(){
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{StoryRaft()}}
 override fun onResume(){super.onResume(); window.decorView.post { StoryRaftUpdater.installPending(this) }}
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun StoryRaft(){
 var dark by remember{mutableStateOf(true)}
 var tab by remember{mutableStateOf("Library")}
 var search by remember{mutableStateOf("")}
 var opened by remember{mutableStateOf<String?>(null)}
 var imported by remember{mutableStateOf(listOf<String>())}
 var firebaseStories by remember{mutableStateOf(listOf<Series>())}
 var catalogStatus by remember{mutableStateOf("Connecting to Firebase…")}
 var automaticRelease by remember{mutableStateOf<StoryRaftUpdater.Release?>(null)}
 val appContext = LocalContext.current
 DisposableEffect(Unit) {
  val registration = FirebaseFirestore.getInstance()
   .collection("stories")
   .addSnapshotListener { snapshot, error ->
    if (error != null) {
     catalogStatus = "Could not load Firebase catalog: ${error.localizedMessage ?: "Unknown error"}"
    } else if (snapshot != null) {
     firebaseStories = snapshot.documents.mapNotNull { doc ->
      val title = doc.getString("title") ?: return@mapNotNull null
      Series(
       title = title,
       chapter = doc.getString("chapter") ?: "No chapter information",
       genre = doc.getString("genre") ?: "Story",
       progress = 0f,
       colors = listOf(Color(0xFF17345C), Color(0xFF496D91))
      )
     }
     catalogStatus = if (firebaseStories.isEmpty()) "No stories in your Firebase catalog yet." else ""
    }
   }
  onDispose { registration.remove() }
 }
 LaunchedEffect(Unit) {
  val prefs = appContext.getSharedPreferences("storyraft_updates", Context.MODE_PRIVATE)
  val lastCheck = prefs.getLong("last_check", 0L)
  if (System.currentTimeMillis() - lastCheck > 24L * 60L * 60L * 1000L) {
   prefs.edit().putLong("last_check", System.currentTimeMillis()).apply()
   StoryRaftUpdater.check { result -> result.onSuccess { r ->
    if (StoryRaftUpdater.isNewer(r.version, BuildConfig.VERSION_NAME)) automaticRelease = r
   } }
  }
 }
 val picker= rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){ uri ->
   uri?.let { imported=imported+(it.lastPathSegment?.substringAfterLast('/') ?: "Imported CBZ") }
 }
 val colors=if(dark) darkColorScheme(primary=Color(0xFFB8C7FF),background=Color(0xFF101318),surface=Color(0xFF191E25),surfaceVariant=Color(0xFF252C35)) else lightColorScheme(primary=Color(0xFF405A9A),background=Color(0xFFF6F7FA),surface=Color.White,surfaceVariant=Color(0xFFE9ECF2))
 MaterialTheme(colorScheme=colors){
  if(opened!=null) Reader(opened!!,{opened=null}) else Scaffold(
   topBar={TopAppBar(title={Column{Text("StoryRaft",fontWeight=FontWeight.Bold);Text("Your stories, in one place",style=MaterialTheme.typography.labelSmall,color=colors.onSurfaceVariant)}},actions={
    IconButton({dark=!dark}){Icon(if(dark)Icons.Default.LightMode else Icons.Default.DarkMode,"Toggle theme")}
    IconButton({picker.launch(arrayOf("application/zip","application/octet-stream"))}){Icon(Icons.Default.Add,"Import CBZ")}
   })},
   bottomBar={NavigationBar{listOf("Library","Browse","Updates","History","Settings").forEach{item->
    val icon=when(item){"Library"->Icons.Default.CollectionsBookmark;"Browse"->Icons.Default.Explore;"Updates"->Icons.Default.Update;"History"->Icons.Default.History;else->Icons.Default.Settings}
    NavigationBarItem(
      selected = tab == item,
      onClick = { tab = item },
      icon = { Icon(icon, contentDescription = item) },
      label = { Text(item) }
     )
   }}}
  ){ pad ->
   when(tab){
    "Library"->Column(Modifier.padding(pad).fillMaxSize().padding(horizontal=16.dp)){
     Spacer(Modifier.height(10.dp));Row(verticalAlignment=Alignment.CenterVertically){Text("Library",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold);Spacer(Modifier.weight(1f));Text("${firebaseStories.size + imported.size} titles",color=colors.onSurfaceVariant)}
     Spacer(Modifier.height(12.dp))
     OutlinedTextField(search,{search=it},Modifier.fillMaxWidth(),placeholder={Text("Search your library")},leadingIcon={Icon(Icons.Default.Search,null)},singleLine=true,shape=RoundedCornerShape(16.dp))
     Spacer(Modifier.height(10.dp));Row(horizontalArrangement=Arrangement.spacedBy(7.dp)){AssistChip({},{Text("All")});AssistChip({},{Text("Unread")});AssistChip({},{Text("Downloaded")});AssistChip({},{Text("Filters")})}
     if(firebaseStories.isEmpty() && imported.isEmpty()){
      Box(Modifier.fillMaxWidth().weight(1f),contentAlignment=Alignment.Center){
       Column(horizontalAlignment=Alignment.CenterHorizontally){
        Icon(Icons.Default.MenuBook,null,tint=colors.onSurfaceVariant,modifier=Modifier.size(48.dp))
        Spacer(Modifier.height(12.dp))
        Text(if(search.isBlank()) "Your library is empty" else "No stories found",fontWeight=FontWeight.SemiBold)
        Text(if(search.isBlank()) catalogStatus else "Try a different search.",color=colors.onSurfaceVariant,style=MaterialTheme.typography.bodySmall)
       }
      }
     } else LazyVerticalGrid(GridCells.Adaptive(112.dp),contentPadding=PaddingValues(vertical=12.dp),horizontalArrangement=Arrangement.spacedBy(12.dp),verticalArrangement=Arrangement.spacedBy(15.dp)){
      items((firebaseStories.filter{it.title.contains(search,true)} + imported.filter{it.contains(search,true)}.map{Series(it,"Imported archive","Local",0f,listOf(Color(0xFF34495E),Color(0xFF7F8C8D)))})){ s->
       Column(Modifier.clickable{opened=s.title}){
        Box(Modifier.fillMaxWidth().aspectRatio(.70f).clip(RoundedCornerShape(12.dp)).background(Brush.linearGradient(s.colors)).padding(10.dp)){
         Column(Modifier.align(Alignment.BottomStart)){Text(s.genre.uppercase(),style=MaterialTheme.typography.labelSmall,color=Color.White);Text(s.title,color=Color.White,fontWeight=FontWeight.Bold,style=MaterialTheme.typography.titleMedium,maxLines=3,overflow=TextOverflow.Ellipsis)}
         Icon(Icons.Default.Bookmark,null,tint=Color.White,modifier=Modifier.align(Alignment.TopEnd))
        }
        Spacer(Modifier.height(6.dp));Text(s.title,fontWeight=FontWeight.SemiBold,maxLines=1,overflow=TextOverflow.Ellipsis);Text(s.chapter,style=MaterialTheme.typography.labelSmall,color=colors.onSurfaceVariant,maxLines=1,overflow=TextOverflow.Ellipsis)
        LinearProgressIndicator(progress={s.progress},Modifier.fillMaxWidth().padding(top=6.dp).height(3.dp))
       }
      }
     }
    }
    "Browse"->Info(pad,"Browse","Stories are loaded directly from your Firebase Firestore catalog.",listOf("${firebaseStories.size} stories available","Collection: stories","Add story documents in Firebase Console"))
    "Updates"->Info(pad,"Latest updates","New chapters from followed sources will appear here.",listOf("No source updates yet"))
    "History"->Info(pad,"Reading history","Your recently read stories will appear here.",listOf("Nothing read yet"))
    else->UpdateSettings(Modifier.padding(pad), dark, { dark=it })
   }
  }
  automaticRelease?.let { release ->
   AlertDialog(
    onDismissRequest={automaticRelease=null},
    title={Text("StoryRaft update available")},
    text={Column { Text("Version ${release.version} is ready to download."); Spacer(Modifier.height(8.dp)); Text(release.notes.take(900), maxLines=6, overflow=TextOverflow.Ellipsis, style=MaterialTheme.typography.bodySmall) }},
    confirmButton={TextButton(onClick={StoryRaftUpdater.download(appContext,release); automaticRelease=null}){Text("Download")}},
    dismissButton={TextButton(onClick={automaticRelease=null}){Text("Later")}}
   )
  }
 }
}

@Composable fun UpdateSettings(modifier: Modifier, dark: Boolean, onDark: (Boolean)->Unit) {
 val context = LocalContext.current
 var status by remember { mutableStateOf("Check GitHub Releases for a newer StoryRaft version.") }
 var release by remember { mutableStateOf<StoryRaftUpdater.Release?>(null) }
 var checking by remember { mutableStateOf(false) }
 Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
  Text("Settings", style=MaterialTheme.typography.headlineMedium, fontWeight=FontWeight.Bold)
  ListItem(headlineContent={Text("Dark theme")}, supportingContent={Text("Switch between light and dark appearance")}, leadingContent={Icon(Icons.Default.Contrast,null)}, trailingContent={Switch(dark,onDark)})
  HorizontalDivider()
  Text("App updates", style=MaterialTheme.typography.titleLarge, fontWeight=FontWeight.SemiBold, modifier=Modifier.padding(top=18.dp,bottom=4.dp))
  Text("Installed version ${BuildConfig.VERSION_NAME}", color=MaterialTheme.colorScheme.onSurfaceVariant)
  Spacer(Modifier.height(10.dp))
  Button(enabled=!checking, onClick={
   checking=true; release=null; status="Checking GitHub Releases…"
   StoryRaftUpdater.check { result ->
    checking=false
    result.onSuccess { r ->
     release=r
     status=if(StoryRaftUpdater.isNewer(r.version,BuildConfig.VERSION_NAME)) "Version ${r.version} is available." else "StoryRaft is up to date."
    }.onFailure { status="Update check failed: ${it.message ?: "Unknown error"}" }
   }
  }) { if(checking) CircularProgressIndicator(Modifier.size(18.dp),strokeWidth=2.dp) else Icon(Icons.Default.Refresh,null); Spacer(Modifier.width(8.dp)); Text("Check for updates") }
  Spacer(Modifier.height(8.dp)); Text(status, style=MaterialTheme.typography.bodyMedium)
  release?.let { r ->
   if(StoryRaftUpdater.isNewer(r.version,BuildConfig.VERSION_NAME)) {
    Spacer(Modifier.height(8.dp)); Text("Release notes",fontWeight=FontWeight.Bold)
    Text(r.notes.take(1600),style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant,maxLines=10,overflow=TextOverflow.Ellipsis)
    Spacer(Modifier.height(8.dp))
    Button(onClick={
     try { StoryRaftUpdater.download(context,r); status="Download started. Android will prompt you to install the update when it finishes." }
     catch(e:Exception) { status="Could not start download: ${e.message}" }
    }) { Icon(Icons.Default.Download,null); Spacer(Modifier.width(8.dp)); Text("Download update") }
   }
  }
  HorizontalDivider(Modifier.padding(vertical=14.dp))
  listOf("Reader settings","Downloads","Library categories","Backup and restore","About StoryRaft · ${BuildConfig.VERSION_NAME}").forEach { ListItem(headlineContent={Text(it)},leadingContent={Icon(Icons.Default.Tune,null)}); HorizontalDivider() }
  Spacer(Modifier.height(16.dp)); Text("Catalog and update information are loaded directly from Firebase.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
 }
}

@Composable fun Info(pad:PaddingValues,title:String,desc:String,rows:List<String>){Column(Modifier.padding(pad).fillMaxSize().padding(20.dp)){Text(title,style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold);Spacer(Modifier.height(8.dp));Text(desc,color=MaterialTheme.colorScheme.onSurfaceVariant);Spacer(Modifier.height(18.dp));rows.forEach{ListItem(headlineContent={Text(it)},leadingContent={Icon(Icons.Default.MenuBook,null)});HorizontalDivider()}}}
@Composable fun Reader(title:String,back:()->Unit){
 var controls by remember{mutableStateOf(true)}
 Column(Modifier.fillMaxSize().background(Color(0xFF101010))){
  if(controls)Row(Modifier.fillMaxWidth().background(Color(0xFF202020)).padding(8.dp),verticalAlignment=Alignment.CenterVertically){IconButton(back){Icon(Icons.Default.ArrowBack,null,tint=Color.White)};Text(title,color=Color.White,fontWeight=FontWeight.SemiBold);Spacer(Modifier.weight(1f));IconButton({controls=false}){Icon(Icons.Default.Fullscreen,null,tint=Color.White)}}
  Box(Modifier.weight(1f).fillMaxWidth().clickable{controls=!controls},contentAlignment=Alignment.Center){Column(horizontalAlignment=Alignment.CenterHorizontally){Icon(Icons.Default.MenuBook,null,tint=Color.LightGray,modifier=Modifier.size(72.dp));Spacer(Modifier.height(12.dp));Text("Reader preview",color=Color.White);Text("Page rendering will be added with archive support.",color=Color.LightGray,style=MaterialTheme.typography.bodySmall)}}
  if(controls)Row(Modifier.fillMaxWidth().background(Color(0xFF202020)).padding(16.dp),horizontalArrangement=Arrangement.Center){Text("Chapter preview",color=Color.White)}
 }
}
