package com.vulpis.storyraft

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import coil.compose.AsyncImage
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration

private val Navy = Color(0xFF081B3D)
private val Blue = Color(0xFF1768C5)
private val Paper = Color(0xFFF4EFE6)
private val Ink = Color(0xFF202733)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FirebaseApp.initializeApp(this)
        setContent { StoryRaftApp() }
    }
}

data class ChapterMeta(val id: String, val title: String, val part: String?, val at: Long?)
data class Story(
    val id: String, val title: String, val author: String, val intro: String,
    val thumb: String?, val updatedAt: Long, val createdAt: Long,
    val chapters: List<ChapterMeta>, val notWriter: Boolean
)
data class Scene(val id: String, val name: String, val text: String, val size: Int, val bold: Boolean, val italic: Boolean, val align: String)

class StoryRepository {
    private val db = FirebaseFirestore.getInstance()
    fun observeStories(onResult: (List<Story>, String?) -> Unit): ListenerRegistration {
        return db.collection("stories").addSnapshotListener { snap, err ->
            if (err != null) { onResult(emptyList(), err.localizedMessage); return@addSnapshotListener }
            val rows = snap?.documents.orEmpty().mapNotNull { d ->
                val rawChapters = d.get("chapters") as? List<Map<String, Any?>> ?: emptyList()
                val chapters = rawChapters.mapNotNull { c ->
                    val id = c["id"] as? String ?: return@mapNotNull null
                    ChapterMeta(id, c["title"] as? String ?: "", c["part"] as? String, (c["at"] as? Number)?.toLong())
                }
                Story(d.id, d.getString("title") ?: "Untitled", d.getString("author") ?: "Unknown",
                    d.getString("intro") ?: "", d.getString("thumb"),
                    (d.get("updatedAt") as? Number)?.toLong() ?: (d.get("createdAt") as? Number)?.toLong() ?: 0L,
                    (d.get("createdAt") as? Number)?.toLong() ?: 0L, chapters, d.getBoolean("notWriter") ?: false)
            }.sortedByDescending { it.updatedAt }
            onResult(rows, null)
        }
    }
    fun loadChapter(storyId: String, chapterId: String, onResult: (List<Scene>, String?) -> Unit) {
        db.collection("chapters").document("${storyId}_${chapterId}").get()
            .addOnSuccessListener { doc ->
                val scenes = (doc.get("scenes") as? List<Map<String, Any?>>).orEmpty().map { s ->
                    val fmt = s["fmt"] as? Map<*, *> ?: emptyMap<Any, Any>()
                    Scene(s["id"] as? String ?: "", s["name"] as? String ?: "", s["text"] as? String ?: "",
                        (fmt["size"] as? Number)?.toInt() ?: 18, fmt["bold"] as? Boolean ?: false,
                        fmt["italic"] as? Boolean ?: false, fmt["align"] as? String ?: "justify")
                }
                onResult(scenes, null)
            }.addOnFailureListener { onResult(emptyList(), it.localizedMessage) }
    }
}

@Composable fun StoryRaftApp() {
    val repo = remember { StoryRepository() }
    var stories by remember { mutableStateOf(emptyList<Story>()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var tab by remember { mutableStateOf("Home") }
    var selected by remember { mutableStateOf<Story?>(null) }
    var reading by remember { mutableStateOf(false) }
    var chapterIndex by remember { mutableIntStateOf(0) }
    var scenes by remember { mutableStateOf(emptyList<Scene>()) }
    var sceneError by remember { mutableStateOf<String?>(null) }
    var query by remember { mutableStateOf("") }
    var layout by remember { mutableStateOf("Classic") }
    var theme by remember { mutableStateOf("Paper") }
    var fontSize by remember { mutableFloatStateOf(19f) }
    var continuous by remember { mutableStateOf(false) }
    var bookmarked by remember { mutableStateOf(false) }
    DisposableEffect(repo) { val listener = repo.observeStories { rows, e -> stories = rows; error = e; loading = false }; onDispose { listener.remove() } }
    MaterialTheme(colorScheme = lightColorScheme(primary = Blue, background = Paper, surface = Paper, onBackground = Ink, onSurface = Ink)) {
        if (reading && selected != null) {
            ReaderScreen(selected!!, chapterIndex, scenes, sceneError, fontSize, { fontSize = it }, theme, { theme = it }, continuous, { continuous = it }, bookmarked, { bookmarked = it },
                onBack = { reading = false }, onPrev = { if (chapterIndex > 0) { chapterIndex--; load(repo, selected!!, chapterIndex) { s,e -> scenes=s; sceneError=e } } },
                onNext = { if (chapterIndex < selected!!.chapters.lastIndex) { chapterIndex++; load(repo, selected!!, chapterIndex) { s,e -> scenes=s; sceneError=e } } })
        } else if (selected != null) {
            DetailScreen(selected!!, onBack = { selected = null }, onRead = { idx -> chapterIndex = idx; load(repo, selected!!, idx) { s,e -> scenes=s; sceneError=e }; reading = true })
        } else {
            Scaffold(containerColor = Paper, bottomBar = {
                NavigationBar(containerColor = Navy, contentColor = Color.White) {
                    listOf("Home", "Library", "Dashboard", "History", "Settings").forEach { name ->
                        val icon = when(name) { "Home" -> Icons.Default.Home; "Library" -> Icons.Default.MenuBook; "Dashboard" -> Icons.Default.Dashboard; "History" -> Icons.Default.History; else -> Icons.Default.Settings }
                        NavigationBarItem(selected = tab == name, onClick = { tab = name }, icon = { Icon(icon, null) }, label = { Text(name, fontSize = 10.sp) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Color.White, selectedTextColor = Color.White, indicatorColor = Blue, unselectedIconColor = Color.LightGray, unselectedTextColor = Color.LightGray))
                    }
                }
            }) { pad ->
                Column(Modifier.fillMaxSize().padding(pad).background(Paper)) {
                    when(tab) {
                        "Home" -> HomeScreen(stories, loading, error, query, { query=it }, layout, onOpen = { selected=it })
                        "Library" -> LibraryScreen(stories, query, { query=it }, layout, onOpen = { selected=it })
                        "Dashboard" -> SimpleScreen("Dashboard", "Your reading activity and saved progress will appear here.")
                        "History" -> SimpleScreen("History", "Recently opened books will appear here.")
                        else -> SettingsScreen(layout, { layout=it }, theme, { theme=it }, fontSize, { fontSize=it })
                    }
                }
            }
        }
    }
}

private fun load(repo: StoryRepository, story: Story, idx: Int, done: (List<Scene>, String?) -> Unit) {
    story.chapters.getOrNull(idx)?.let { repo.loadChapter(story.id, it.id, done) } ?: done(emptyList(), "This story has no chapters yet.")
}

@Composable private fun Header(title: String, subtitle: String? = null) {
    Column(Modifier.fillMaxWidth().background(Navy).padding(horizontal=20.dp, vertical=18.dp)) {
        Text(title, color=Color.White, fontSize=25.sp, fontWeight=FontWeight.Bold)
        if (subtitle != null) Text(subtitle, color=Color(0xFFB8D6FF), fontSize=13.sp)
    }
}
@Composable private fun SearchField(value: String, onChange: (String)->Unit) {
    OutlinedTextField(value, onChange, Modifier.fillMaxWidth().padding(horizontal=16.dp, vertical=10.dp), placeholder={Text("Search stories…")}, leadingIcon={Icon(Icons.Default.Search, null)}, singleLine=true, shape=RoundedCornerShape(16.dp))
}
@Composable private fun HomeScreen(stories: List<Story>, loading: Boolean, error: String?, query: String, onQuery: (String)->Unit, layout: String, onOpen: (Story)->Unit) {
    Column(Modifier.fillMaxSize()) {
        Header("StoryRaft", "Discover your next story")
        SearchField(query, onQuery)
        LazyColumn(contentPadding=PaddingValues(bottom=16.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
            item {
                Column(Modifier.padding(horizontal=16.dp)) {
                    Text("Featured", fontSize=20.sp, fontWeight=FontWeight.Bold, color=Navy)
                    Box(Modifier.fillMaxWidth().height(148.dp).padding(top=8.dp).clip(RoundedCornerShape(18.dp)).background(Navy), contentAlignment=Alignment.Center) {
                        Column(horizontalAlignment=Alignment.CenterHorizontally) { Text("A sea of stories awaits", color=Color.White, fontSize=19.sp, fontWeight=FontWeight.SemiBold); Text("Featured banners will be connected to the admin feed", color=Color(0xFFB8D6FF), fontSize=11.sp) }
                    }
                }
            }
            item { SectionHeading("Recently Updated", "Latest changes first") }
            if (loading) item { CenterMessage("Loading stories from Firebase…") }
            if (error != null) item { CenterMessage("Firebase: $error") }
            val latest = stories.filter { it.title.contains(query, true) || it.author.contains(query, true) }.take(5)
            items(latest.chunked(2)) { pair -> Row(Modifier.fillMaxWidth().padding(horizontal=16.dp), horizontalArrangement=Arrangement.spacedBy(10.dp)) { pair.forEach { StoryCard(it, layout, Modifier.weight(1f), onOpen) }; if(pair.size==1) Spacer(Modifier.weight(1f)) } }
            item { SectionHeading("Popular", "Discover reader favourites") }
            items(stories.take(8).chunked(2)) { pair -> Row(Modifier.fillMaxWidth().padding(horizontal=16.dp), horizontalArrangement=Arrangement.spacedBy(10.dp)) { pair.forEach { StoryCard(it, layout, Modifier.weight(1f), onOpen) }; if(pair.size==1) Spacer(Modifier.weight(1f)) } }
        }
    }
}
@Composable private fun SectionHeading(title: String, caption: String) { Column(Modifier.padding(horizontal=16.dp, vertical=2.dp)) { Text(title, fontSize=20.sp, fontWeight=FontWeight.Bold, color=Navy); Text(caption, fontSize=12.sp, color=Color.Gray) } }
@Composable private fun StoryCard(story: Story, layout: String, modifier: Modifier, onOpen: (Story)->Unit) {
    Column(modifier.clip(RoundedCornerShape(14.dp)).background(Color.White).clickable { onOpen(story) }.padding(9.dp)) {
        if (story.thumb != null) AsyncImage(story.thumb, null, Modifier.fillMaxWidth().height(if(layout=="Immersive") 170.dp else 128.dp).clip(RoundedCornerShape(10.dp)), contentScale=ContentScale.Crop)
        else Box(Modifier.fillMaxWidth().height(128.dp).clip(RoundedCornerShape(10.dp)).background(Navy), contentAlignment=Alignment.Center) { Text(story.title.take(32), color=Color.White, fontWeight=FontWeight.Bold, modifier=Modifier.padding(8.dp)) }
        Spacer(Modifier.height(7.dp)); Text(story.title, fontWeight=FontWeight.SemiBold, maxLines=2, overflow=TextOverflow.Ellipsis); Text(story.author, fontSize=12.sp, color=Color.Gray, maxLines=1)
    }
}
@Composable private fun LibraryScreen(stories: List<Story>, query: String, onQuery: (String)->Unit, layout: String, onOpen: (Story)->Unit) {
    Column { Header("Library", "Your shelves and saved books"); SearchField(query,onQuery); LazyColumn(contentPadding=PaddingValues(14.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) {
        items(stories.filter { it.title.contains(query,true) || it.author.contains(query,true) }) { s -> Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color.White).clickable { onOpen(s) }.padding(10.dp), horizontalArrangement=Arrangement.spacedBy(12.dp)) {
            if(s.thumb!=null) AsyncImage(s.thumb,null,Modifier.width(72.dp).height(100.dp).clip(RoundedCornerShape(8.dp)), contentScale=ContentScale.Crop) else Box(Modifier.width(72.dp).height(100.dp).background(Navy), contentAlignment=Alignment.Center){Text("SR",color=Color.White)}
            Column(Modifier.weight(1f)) { Text(s.title,fontWeight=FontWeight.Bold); Text(s.author,color=Color.Gray,fontSize=13.sp); Text("${s.chapters.size} chapters",fontSize=12.sp); Text("Updated ${if(s.updatedAt>0) java.text.SimpleDateFormat("MMM d, yyyy", java.util.Locale.getDefault()).format(java.util.Date(s.updatedAt)) else "—"}",fontSize=11.sp,color=Blue) }
        } }
    } }
}
@Composable private fun DetailScreen(story: Story, onBack: ()->Unit, onRead: (Int)->Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().background(Navy).padding(12.dp), verticalAlignment=Alignment.CenterVertically) { IconButton(onBack) { Icon(Icons.Default.ArrowBack,null,tint=Color.White) }; Text("Book Details",color=Color.White,fontSize=20.sp,fontWeight=FontWeight.Bold) }
        LazyColumn(Modifier.weight(1f), contentPadding=PaddingValues(18.dp)) {
            item { Row(horizontalArrangement=Arrangement.spacedBy(16.dp)) { if(story.thumb!=null) AsyncImage(story.thumb,null,Modifier.width(112.dp).height(160.dp).clip(RoundedCornerShape(12.dp)),contentScale=ContentScale.Crop) else Box(Modifier.width(112.dp).height(160.dp).background(Navy),contentAlignment=Alignment.Center){Text("StoryRaft",color=Color.White)}; Column(Modifier.weight(1f)) { Text(story.title,fontSize=22.sp,fontWeight=FontWeight.Bold,color=Navy); Text(story.author,color=Color.Gray); Spacer(Modifier.height(10.dp)); Text("${story.chapters.size} chapters",fontSize=13.sp); OutlinedButton(onClick={if(story.chapters.isNotEmpty())onRead(0)},enabled=story.chapters.isNotEmpty()) { Text("Start reading") } } } }
            item { Spacer(Modifier.height(18.dp)); Text("About this book",fontWeight=FontWeight.Bold,fontSize=18.sp); Text(story.intro.ifBlank { "No synopsis has been added." },Modifier.padding(top=6.dp),lineHeight=22.sp) }
            item { Spacer(Modifier.height(20.dp)); Text("Chapters",fontWeight=FontWeight.Bold,fontSize=19.sp,color=Navy) }
            itemsIndexed(story.chapters) { idx, ch ->
                if (!ch.part.isNullOrBlank() && (idx==0 || story.chapters[idx-1].part != ch.part)) Text(ch.part,Modifier.fillMaxWidth().padding(top=14.dp,bottom=5.dp),fontSize=14.sp,color=Blue,fontWeight=FontWeight.SemiBold)
                Row(Modifier.fillMaxWidth().clickable { onRead(idx) }.padding(vertical=12.dp),verticalAlignment=Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(ch.title.ifBlank { "Chapter ${idx+1}" },fontWeight=FontWeight.Medium); Text("Chapter ${idx+1}",fontSize=11.sp,color=Color.Gray) }; Icon(Icons.Default.ChevronRight,null,tint=Blue) }
                HorizontalDivider(color=Color(0xFFE4DED4))
            }
        }
    }
}
@Composable private fun ReaderScreen(story: Story, index: Int, scenes: List<Scene>, error: String?, fontSize: Float, onFont: (Float)->Unit, theme: String, onTheme: (String)->Unit, continuous: Boolean, onContinuous: (Boolean)->Unit, bookmarked: Boolean, onBookmark: (Boolean)->Unit, onBack: ()->Unit, onPrev: ()->Unit, onNext: ()->Unit) {
    val bg = when(theme) { "Night" -> Color(0xFF101722); "Sepia" -> Color(0xFFF0E1C5); else -> Paper }
    val fg = if(theme=="Night") Color(0xFFE6EAF0) else Ink
    var tools by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().background(bg)) {
        Row(Modifier.fillMaxWidth().background(Navy).padding(horizontal=8.dp, vertical=5.dp),verticalAlignment=Alignment.CenterVertically) { IconButton(onBack){Icon(Icons.Default.ArrowBack,null,tint=Color.White)}; Column(Modifier.weight(1f)){Text(story.title,color=Color.White,maxLines=1);Text("${index+1} / ${story.chapters.size}",color=Color.LightGray,fontSize=11.sp)}; IconButton(onClick={onBookmark(!bookmarked)}){Icon(if(bookmarked)Icons.Default.Bookmark else Icons.Default.BookmarkBorder,null,tint=Color.White)}; IconButton(onClick={tools=!tools}){Icon(Icons.Default.Tune,null,tint=Color.White)} }
        if(tools) Column(Modifier.fillMaxWidth().background(bg).padding(12.dp)) { Text("Text size ${fontSize.toInt()}sp",color=fg); Slider(fontSize,onFont,valueRange=14f..32f); Row(verticalAlignment=Alignment.CenterVertically){ listOf("Paper","Sepia","Night").forEach { FilterChip(selected=theme==it,onClick={onTheme(it)},label={Text(it)}) } }; Row(verticalAlignment=Alignment.CenterVertically){Text("Continuous scroll",color=fg); Spacer(Modifier.width(8.dp)); Switch(continuous,onContinuous)} }
        Text(story.chapters.getOrNull(index)?.title?.ifBlank { "Chapter ${index+1}" } ?: "",Modifier.align(Alignment.CenterHorizontally).padding(10.dp),color=fg,fontWeight=FontWeight.SemiBold)
        if(error!=null) CenterMessage(error) else if(scenes.isEmpty()) CenterMessage("Loading chapter…") else LazyColumn(Modifier.weight(1f).fillMaxWidth(),contentPadding=PaddingValues(horizontal=24.dp,vertical=18.dp)) {
            items(scenes) { scene -> Column(Modifier.fillMaxWidth().padding(bottom=18.dp)) { if(scene.name.isNotBlank()) Text(scene.name,color=fg,fontWeight=FontWeight.Bold); Text(scene.text,color=fg,fontSize=fontSize.sp,lineHeight=(fontSize*1.55).sp,fontWeight=if(scene.bold)FontWeight.Bold else FontWeight.Normal) } }
        }
        Row(Modifier.fillMaxWidth().padding(12.dp),horizontalArrangement=Arrangement.SpaceBetween) { OutlinedButton(onClick=onPrev,enabled=index>0){Text("Previous")}; OutlinedButton(onClick=onNext,enabled=index<story.chapters.lastIndex){Text("Next chapter") } }
    }
}
@Composable private fun SettingsScreen(layout: String,onLayout:(String)->Unit,theme:String,onTheme:(String)->Unit,fontSize:Float,onFont:(Float)->Unit) {
    val layouts=listOf("Minimal","Classic","Cards","List","Editorial","Immersive","Aurora")
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) { Header("Settings", "Make StoryRaft feel like yours"); Text("Home layout",Modifier.padding(start=18.dp,top=18.dp),fontWeight=FontWeight.Bold,fontSize=18.sp); layouts.forEach { Row(Modifier.fillMaxWidth().clickable{onLayout(it)}.padding(horizontal=18.dp,vertical=10.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(it,fontWeight=FontWeight.Medium);Text(if(it=="Classic")"Balanced cover grid and shelves" else "Alternative presentation",fontSize=11.sp,color=Color.Gray)};RadioButton(layout==it,{onLayout(it)})} }; HorizontalDivider(); Text("Reading theme",Modifier.padding(18.dp),fontWeight=FontWeight.Bold); Row(Modifier.padding(horizontal=12.dp)){listOf("Paper","Sepia","Night").forEach{FilterChip(selected=theme==it,onClick={onTheme(it)},label={Text(it)},modifier=Modifier.padding(end=6.dp))}}; Text("Default text size: ${fontSize.toInt()}sp",Modifier.padding(start=18.dp,top=12.dp)); Slider(fontSize,onFont,Modifier.padding(horizontal=18.dp),valueRange=14f..32f); Text("Account",Modifier.padding(18.dp),fontWeight=FontWeight.Bold); Text(FirebaseAuth.getInstance().currentUser?.email ?: "Not signed in",Modifier.padding(horizontal=18.dp),color=Color.Gray); Text("Sign-in and account management are not yet connected to the interface.",Modifier.padding(18.dp),fontSize=12.sp,color=Color.Gray) }
}
@Composable private fun SimpleScreen(title:String,body:String){Column(Modifier.fillMaxSize()){Header(title);CenterMessage(body)}}
@Composable private fun CenterMessage(text:String){Box(Modifier.fillMaxWidth().padding(20.dp),contentAlignment=Alignment.Center){Text(text,color=Color.Gray)}}
