# StoryRaft for Android

An original Android manga/comic library UI starter with its own branding and implementation. It does not contain Mihon source code, branding, or assets.

- App name: **StoryRaft**
- Android application ID: `com.vulpis.storyraft`
- Kotlin namespace: `com.vulpis.storyraft`
- Website/App Link host: `storyraft.vulpis.workers.dev`
- Minimum Android: 7.0 (API 24)
- Stack: Kotlin, Jetpack Compose, Material 3

## Build with GitHub Actions
1. Create a GitHub repository and upload the contents of this folder.
2. Open **Actions** and select **Build StoryRaft APK**.
3. Click **Run workflow** (or push to `main` / `master`).
4. Download the `StoryRaft-debug-apk` artifact from the completed run.
5. Install the APK on Android. This is a debug build; configure signing for public release.

## Domain
The Android manifest declares an HTTPS App Link for `https://storyraft.vulpis.workers.dev`. To verify App Links, the website must serve `/.well-known/assetlinks.json` containing the package name and SHA-256 signing-certificate fingerprint. This repository does not deploy or create the Cloudflare Worker/site.

## Included in this starter
- Original StoryRaft name and application ID.
- Light/dark theme toggle.
- Library grid, search, sample entries, progress bars, and filters UI.
- Bottom navigation: Library, Browse, Updates, History, Settings.
- Import-file picker entry point for CBZ/ZIP.
- Reader preview screen.
- GitHub Actions APK workflow.

## Not yet implemented
This is a UI starter, not yet a complete manga platform. Browse and Updates are placeholders; the CBZ picker currently records the selected filename but does not extract/render archive pages. Remote source adapters, extension runtime, chapter downloads, persistent database, reading history, backups, and a production reader engine still need implementation. No manga sources are bundled.


## In-app update system

StoryRaft can check the latest GitHub Release from **Settings → Check for updates**, compare its version tag with the installed app, show release notes, download the APK, and hand it to Android's package installer.

Before publishing, edit `app/build.gradle.kts` and change `UPDATE_REPOSITORY` from `OWNER/REPOSITORY` to your actual GitHub `owner/repository`.

For each update:
1. Increase `versionCode` and `versionName` in `app/build.gradle.kts`.
2. Build a release APK signed with the same signing key as the installed app.
3. Create a GitHub Release with a tag such as `v1.0.1` and attach the APK asset.

Android requires user approval for normal APK installation. Users may also need to allow StoryRaft to install unknown apps. The updater cannot silently install on ordinary consumer devices.

**Signing warning:** The included Actions workflow currently produces a debug APK. A production update channel needs a signed release workflow and persistent signing-key GitHub secrets. Do not change signing keys between releases, or Android will reject the update.

### GitHub repository and signing setup (required for real updates)

1. Set `UPDATE_REPOSITORY` in `app/build.gradle.kts` to the public GitHub repository that will host StoryRaft releases, for example `your-account/StoryRaft`.
2. Create one Android signing keystore and keep it safe. Never regenerate it for later updates.
3. Add these GitHub Actions repository secrets:
   - `ANDROID_KEYSTORE_BASE64`: base64-encoded keystore file
   - `ANDROID_KEYSTORE_PASSWORD`: keystore password
   - `ANDROID_KEY_ALIAS`: key alias
   - `ANDROID_KEY_PASSWORD`: key password
4. Push a tag such as `v1.0.1` after increasing `versionCode` and `versionName`. The `Publish StoryRaft release` workflow builds and attaches the signed APK to the GitHub Release.

The updater checks the public GitHub Releases API and expects an APK asset attached to the latest release. A repository name and signing secrets are not included because they must belong to the app owner.
