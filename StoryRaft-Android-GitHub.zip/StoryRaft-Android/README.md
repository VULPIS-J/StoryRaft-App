# StoryRaft Android — starter project

This is an Android Studio project scaffold for the StoryRaft reader app, using the existing Firebase project configuration and the website's Firestore data shape.

## Open it
1. Install Android Studio (current stable) with Android SDK 35 and JDK 17.
2. Open this folder (`StoryRaft-Android`) in Android Studio.
3. Allow Gradle sync to download dependencies.
4. Connect an Android device or create an emulator, then Run `app`.

## Firebase integration included
- Uses package `com.vulpis.storyraft` and the supplied `google-services.json`.
- Reads public story documents from `stories`.
- Reads chapter documents from `chapters/{storyId}_{chapterId}`.
- Maps `stories[].chapters[]` metadata, including `part`, `title`, `id`, and `at`.
- Maps chapter `scenes[]` and scene `fmt` fields (`size`, `bold`, `italic`, `align`).

## Included in this first scaffold
- Five bottom destinations: Home, Library, Dashboard, History, Settings.
- Discover-style Home with top search, Featured placeholder, Recently Updated, and Popular sections.
- Recently Updated is limited to five rows, two story cards per row, sorted by `updatedAt`.
- Book details and vertically listed chapters, with `part` headings shown when the value changes.
- Basic reader with chapter loading, font-size control, Paper/Sepia/Night themes, bookmark toggle, and previous/next chapter navigation.
- One consistent app layout; there are no layout presets or layout-selection controls.
- Your supplied StoryRaft logo artwork is copied unchanged into `drawable-nodpi`.

## Not finished yet (important)
This is a **starter implementation, not a finished production app or APK**. The following still need implementation and testing: admin-managed featured-banner data, popularity ranking source, persistent bookmarks/highlights/annotations/reading progress, brightness and orientation controls, page-turn animation and true paginated mode, authentication UI, dashboard/history data, reviews/ratings/genres/tags, cover retrieval from the `covers` collection / Storage, error/loading polish, offline behavior, security-rule review, and end-to-end tests.

The Home Featured area is deliberately a placeholder because no banner collection/schema was present in the supplied website source. Popular is currently a basic story listing, not a popularity-ranked feed.

## Source references
- `reference-index.html` is the supplied website source, included for reference.
- `design-reference-home.png` and `design-reference-updates.png` are the supplied visual references.
- `app/google-services.json` is the Firebase Android client config supplied for this project. Do not publish it alongside private credentials or server keys.

## Build note
The project has not been compiled in this environment because an Android SDK/Gradle installation is not available here. Android Studio will perform the first dependency resolution and build. Review Firebase Security Rules before connecting real users.
